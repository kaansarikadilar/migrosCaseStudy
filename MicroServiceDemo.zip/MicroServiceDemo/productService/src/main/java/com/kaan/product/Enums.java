package com.kaan.product;

public enum Enums {
    KILOGRAM,
    ADET


}
