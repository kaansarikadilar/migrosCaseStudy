package com.kaan.barcode;

public enum barcodeTypes {
    NORMAL,
    CASH,
    SCALE
}
